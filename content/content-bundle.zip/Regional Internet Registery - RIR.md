
RIR, İngilizce olarak "Regional Internet Registry" ifadesinin kısaltmasıdır ve Türkçe'de Bölgesel İnternet Kaydedici Kuruluşu olarak adlandırılır. RIR'ler, belirli bir coğrafi bölgede (Afrika, Asya-Pasifik, Kuzey Amerika, Latin Amerika ve Karayipler, Avrupa, Orta Doğu ve Orta Asya) internet numaraları kaynaklarının (IP adresleri ve AS numaraları) yönetiminden ve dağıtımından sorumlu olan kuruluşlardır.

Şu anda dünya genelinde beş RIR bulunmaktadır:

-   AfriNIC: Afrika'dan sorumludur
-   APNIC: Asya Pasifik bölgesinden sorumludur
-   ARIN: Kuzey Amerika, Karayiplerin bazı bölgeleri ve alt ekvatoriyel Afrika'dan sorumludur
-   LACNIC: Latin Amerika ve Karayipler'den sorumludur
-   RIPE NCC: Avrupa, Orta Doğu ve Orta Asya'dan sorumludur

RIR'ler, kar amacı gütmeyen kuruluşlardır ve Internet Assigned Numbers Authority (IANA) ve Internet Corporation for Assigned Names and Numbers (ICANN) yönlendirmesiyle çalışırlar. Kendi bölgelerindeki internet hizmet sağlayıcıları, ağ işletmecileri ve diğer kuruluşlara IP adresleri ve AS numaraları tahsis ederler.

RIR'ler ayrıca, internet numara kaynaklarının yönetimi ve tahsisi ile ilgili politikaların geliştirilmesi ve teşvik edilmesinde de rol oynarlar. İnternet topluluğu ile yakın işbirliği yaparak, internet numara kaynaklarının adil, verimli ve sürdürülebilir bir şekilde tahsis edilmesi ve kullanılması sağlanır.